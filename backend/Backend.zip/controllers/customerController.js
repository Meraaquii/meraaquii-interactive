const { AddCustomer } = require("../models/customerModels.js");

const addCustomer = async (req, res) => {
  try {
    console.log("REQ BODY:", req.body);

    const result = await AddCustomer(req.body);

    res.status(201).json({
      success: true,
      message: "Customer added successfully",
      customerId: result.insertId,
    });
  } catch (error) {
    console.error("ERROR:", error.message);

    const clientErrors = [
      "Email already exists",
      "client_id is required",
      "customer_name is required",
      "customer_phone_no is required",
      "customer_email is required",
    ];

    if (clientErrors.includes(error.message)) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

module.exports = { addCustomer };
