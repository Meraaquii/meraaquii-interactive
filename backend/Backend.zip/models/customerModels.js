// customerModels.js
const db = require("../config/database.js");

const AddCustomer = async (customerData) => {
  // ← trim all keys to remove accidental spaces
  const trimmed = Object.fromEntries(
    Object.entries(customerData).map(([k, v]) => [k.trim(), v]),
  );

  const {
    customer_name,
    customer_phone_no,
    customer_email,
    customer_address,
    clientId,
    client_id,
    salesman_id,
  } = trimmed;

  const resolvedClientId = client_id ?? clientId;

  if (!resolvedClientId) throw new Error("client_id is required");
  if (!customer_name) throw new Error("customer_name is required");
  if (!customer_phone_no) throw new Error("customer_phone_no is required");
  if (!customer_email) throw new Error("customer_email is required");

  const [existing] = await db.query(
    `SELECT * FROM mr_customer WHERE cus_email = ?`,
    [customer_email],
  );
  if (existing.length > 0) throw new Error("Email already exists");

  const [result] = await db.query(
    `INSERT INTO mr_customer 
     (cus_name, cus_phone, cus_email, cus_address, client_id, salesman_id) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    [
      customer_name,
      customer_phone_no,
      customer_email,
      customer_address,
      resolvedClientId,
      salesman_id,
    ],
  );

  return result;
};

module.exports = { AddCustomer };
