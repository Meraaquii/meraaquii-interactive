// customerRoutes.js
const express = require("express");
const router = express.Router();
const { addCustomer } = require("../controllers/customerController.js");

router.post("/addCustomer", addCustomer);

module.exports = router;
