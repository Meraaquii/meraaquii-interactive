const db = require("../config/database.js");
const bcrypt = require("bcrypt");

const generatePassword = () => {
  const random = Math.floor(100 + Math.random() * 900);
  return `Device@${random}`;
};

const generateUniqueOculusAuthId = async (connection) => {
  let oculas_auth_id;
  let exists = true;
  while (exists) {
    oculas_auth_id = Math.floor(100 + Math.random() * 900).toString();
    const [rows] = await connection.query(
      "SELECT * FROM mr_device WHERE oculas_auth_id = ?",
      [oculas_auth_id],
    );
    if (rows.length === 0) exists = false;
  }
  return oculas_auth_id;
};

//GET ALL
const getAllSalesman = async (user_email, user_type, user_id) => {
  let query = `
    SELECT DISTINCT
      pm.project_id,
      pd.project_name,
      t.tower_name,
      f.floor_name,
      a.appartment_id AS apart_id,
      a.apart_name    AS apartment_name,
      a.appartment_available,
      c.client_name,
      c.client_email,
      pm.project_status,
      pm.created_on,
      ft.flat_type_name,
      sm.salesman_name,
      sm.salesman_email
    FROM mr_project_master pm
    LEFT JOIN mr_project_details pd ON pd.project_id = pm.project_id
    LEFT JOIN mr_client         c  ON c.client_id   = pm.client_id
    LEFT JOIN mr_tower_master   t  ON t.project_id  = pm.project_id
    LEFT JOIN mr_floor_master   f  ON f.tower_id    = t.tower_id
    LEFT JOIN mr_appartment_master a ON a.floor_id  = f.floor_id
    LEFT JOIN mr_flat_type      ft ON ft.flat_type_id = a.flat_type_id
    LEFT JOIN mr_salesman       sm ON sm.client_id  = pm.client_id
  `;

  const conditions = [];
  const params = [];

  if (user_type === "S" && user_id) {
    conditions.push("sm.user_id = ?");
    params.push(user_id);
  }
  if (user_email) {
    conditions.push("c.client_email = ?");
    params.push(user_email);
  }
  if (conditions.length > 0) query += " WHERE " + conditions.join(" AND ");

  const [rows] = await db.query(query, params);
  return rows;
};

// ADD
const addSalesman = async (salesmanData) => {
  const { salesman_name, salesman_phone_no, salesman_email, client_id } =
    salesmanData;
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    const [existing] = await connection.query(
      "SELECT salesman_id FROM mr_salesman WHERE salesman_email = ?",
      [salesman_email],
    );
    if (existing.length > 0) throw new Error("Email already exists");

    const plainPassword = generatePassword();
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    const [userResult] = await connection.query(
      `INSERT INTO mr_user (user_email, user_password, user_type)
       VALUES (?, ?, 'S')`,
      [salesman_email, hashedPassword],
    );
    const user_id = userResult.insertId;

    const [salesmanResult] = await connection.query(
      `INSERT INTO mr_salesman
         (salesman_name, salesman_phone_no, salesman_email, client_id, user_id)
       VALUES (?, ?, ?, ?, ?)`,
      [salesman_name, salesman_phone_no, salesman_email, client_id, user_id],
    );
    const salesman_id = salesmanResult.insertId;

    const device_password = generatePassword();
    const oculas_auth_id = await generateUniqueOculusAuthId(connection);

    await connection.query(
      `INSERT INTO mr_device
         (device_name, device_password, oculas_auth_id, client_id, salesman_id)
       VALUES (?, ?, ?, ?, ?)`,
      [salesman_email, device_password, oculas_auth_id, client_id, salesman_id],
    );

    await connection.commit();

    return {
      message: "Salesman created successfully",
      salesman_id,
      user_id,
      device_name: salesman_email,
      login_password: plainPassword,
      device_password,
      oculas_auth_id,
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

// ─── UPDATE
const updateSalesman = async (id, salesmanData) => {
  const { salesman_name, salesman_phone_no, salesman_email } = salesmanData;
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    const [existingSalesman] = await connection.query(
      "SELECT * FROM mr_salesman WHERE salesman_id = ?",
      [id],
    );
    if (existingSalesman.length === 0) throw new Error("Salesman not found");

    const [duplicateEmail] = await connection.query(
      "SELECT salesman_id FROM mr_salesman WHERE salesman_email = ? AND salesman_id != ?",
      [salesman_email, id],
    );
    if (duplicateEmail.length > 0) throw new Error("Email already exists");

    await connection.query(
      `UPDATE mr_salesman
         SET salesman_name = ?, salesman_phone_no = ?, salesman_email = ?
       WHERE salesman_id = ?`,
      [salesman_name, salesman_phone_no, salesman_email, id],
    );

    await connection.query(
      "UPDATE mr_device SET device_name = ? WHERE salesman_id = ?",
      [salesman_email, id],
    );

    const { user_id } = existingSalesman[0];
    if (user_id) {
      await connection.query(
        "UPDATE mr_user SET user_email = ? WHERE user_id = ?",
        [salesman_email, user_id],
      );
    }

    await connection.commit();
    return {
      message: "Salesman updated successfully",
      salesman_id: id,
      device_name: salesman_email,
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

//  DELETE
const deleteSalesman = async (salesman_id) => {
  const connection = await db.getConnection();

  try {
    await connection.beginTransaction();

    const [salesmanRows] = await connection.query(
      "SELECT user_id FROM mr_salesman WHERE salesman_id = ?",
      [salesman_id],
    );
    if (salesmanRows.length === 0) throw new Error("Salesman not found");
    const { user_id } = salesmanRows[0];

    // Delete device
    const [deviceResult] = await connection.query(
      "DELETE FROM mr_device WHERE salesman_id = ?",
      [salesman_id],
    );

    // Delete salesman
    const [salesmanResult] = await connection.query(
      "DELETE FROM mr_salesman WHERE salesman_id = ?",
      [salesman_id],
    );

    // Delete linked user account  ← NEW
    if (user_id) {
      await connection.query("DELETE FROM mr_user WHERE user_id = ?", [
        user_id,
      ]);
    }

    await connection.commit();
    return {
      deletedSalesman: salesmanResult.affectedRows,
      deletedDevices: deviceResult.affectedRows,
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

module.exports = {
  addSalesman,
  getAllSalesman,
  updateSalesman,
  deleteSalesman,
};
