const {
  addSalesman,
  getAllSalesman: getAllSalesmanModel,
  updateSalesman: updateSalesmanModel,
  deleteSalesman: deleteSalesmanModel,
} = require("../models/salesmanModel");

const getAllSalesman = async (req, res) => {
  try {
    const { user_email, user_type, user_id } = req.query;

    if (user_type === "S" && !user_id) {
      return res.status(400).json({
        success: false,
        message: "user_id is required for salesman access",
      });
    }

    const salesmans = await getAllSalesmanModel(user_email, user_type, user_id);

    res.json({
      success: true,
      data: salesmans,
    });
  } catch (error) {
    console.error("Error in getAllSalesman:", error);
    res.status(500).json({
      success: false,
      message: "Failed to get salesmans",
    });
  }
};

const createSalesman = async (req, res) => {
  try {
    const salesmanData = req.body;

    const { salesman_name, salesman_phone_no, salesman_email, client_id } =
      salesmanData;
    if (!salesman_name || !salesman_phone_no || !salesman_email || !client_id) {
      return res.status(400).json({
        success: false,
        message:
          "salesman_name, salesman_phone_no, salesman_email and client_id are required",
      });
    }

    const result = await addSalesman(salesmanData);

    res.status(201).json({
      success: true,
      message: result.message,
      data: {
        salesman_id: result.salesman_id,
        user_id: result.user_id,
        device_name: result.device_name,
        login_password: result.login_password,
        device_password: result.device_password,
        oculas_auth_id: result.oculas_auth_id,
      },
    });
  } catch (error) {
    console.error("Create Salesman Error:", error.message);

    if (error.message === "Email already exists") {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || "Failed to add salesman",
    });
  }
};

const updateSalesman = async (req, res) => {
  try {
    const id = req.params.id;
    const salesmanData = req.body;

    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Salesman ID is required",
      });
    }

    const result = await updateSalesmanModel(id, salesmanData);

    res.json({
      success: true,
      message: result.message,
      data: {
        salesman_id: result.salesman_id,
        device_name: result.device_name,
      },
    });
  } catch (error) {
    console.error("Update Error:", error.message);

    if (error.message === "Email already exists") {
      return res.status(400).json({ success: false, message: error.message });
    }
    if (error.message === "Salesman not found") {
      return res.status(404).json({ success: false, message: error.message });
    }

    res.status(500).json({
      success: false,
      message: "Failed to update salesman",
    });
  }
};

const deleteSalesman = async (req, res) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Salesman ID is required",
      });
    }

    const deleted = await deleteSalesmanModel(id);

    if (deleted.deletedSalesman === 0) {
      return res.status(404).json({
        success: false,
        message: "Salesman not found",
      });
    }

    res.json({
      success: true,
      message: "Salesman deleted successfully",
      data: deleted,
    });
  } catch (error) {
    console.error("Delete Error:", error.message);

    if (error.message === "Salesman not found or could not be deleted") {
      return res
        .status(404)
        .json({ success: false, message: "Salesman not found" });
    }

    res.status(500).json({
      success: false,
      message: "Server Error",
    });
  }
};

module.exports = {
  getAllSalesman,
  createSalesman,
  updateSalesman,
  deleteSalesman,
};
