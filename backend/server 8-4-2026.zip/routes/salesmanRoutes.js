const express = require("express");

const Router = express.Router();

const {
  getAllSalesman,
  createSalesman,
  updateSalesman,
  deleteSalesman,
} = require("../controllers/salesmanControllers.js");

Router.get("/list", getAllSalesman);
Router.post("/AddSalesman", createSalesman);
Router.put("/UpdateSalesman/:id", updateSalesman);
Router.delete("/DeleteSalesman/:id", deleteSalesman);

module.exports = Router;
