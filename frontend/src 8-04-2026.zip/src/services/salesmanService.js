import API from "../api/apiClient.js";

export const fetchSalesman = async (params = {}) => {
  try {
    const res = await API.get("/salesman/list", { params });
    console.log("Salesman API response:", res.data);
    if (res.data.success) {
      return res.data.data;
    } else {
      console.error("Failed to fetch salesman:", res.data.message);
      return [];
    }
  } catch (error) {
    console.error("Salesman API fetch error:", error);
    return [];
  }
};

export const addSalesman = async (salesmanData) => {
  try {
    const res = await API.post("/salesman/AddSalesman", salesmanData);
    return res.data;
  } catch (error) {
    console.error("Add Salesman API error:", error);
    throw error;
  }
};

export const updateSalesman = async (id, payload) => {
  try {
    const res = await API.put(`/salesman/UpdateSalesman/${id}`, payload);
    return res.data;
  } catch (error) {
    console.error("Update Salesman API error:", error);
    throw error;
  }
};

export const deleteSalesman = async (id) => {
  try {
    const res = await API.delete(`/salesman/DeleteSalesman/${id}`);
    return res.data;
  } catch (error) {
    console.error("Delete Salesman API error:", error);
    throw error;
  }
};
