import { fetchSalesman, deleteSalesman } from "../services/salesmanService";

// Fetch and format salesman data for table
// Pass the full user object from localStorage
export const getSalesmanData = async (setRows, user) => {
  try {
    // Build query params based on user type
    let params = {};

    if (user.user_type === "A") {
      params = { user_type: "A" };
    } else if (user.user_type === "S") {
      params = { user_type: "S", user_id: user.user_id };
    } else if (user.user_type === "C") {
      params = { user_type: "C", user_email: user.user_email };
    }

    const data = await fetchSalesman(params);

    if (!Array.isArray(data)) {
      console.error("Salesman API returned invalid data:", data);
      return;
    }

    const formatted = data.map((item) => ({
      id: item.salesman_id,
      name: item.salesman_name,
      phone: item.salesman_phone_no,
      email: item.salesman_email,
      createdAt: item.created_on,
    }));

    setRows(formatted);
  } catch (error) {
    console.error("Error fetching salesman data:", error);
  }
};

// Delete salesman helper
export const deleteSalesmanData = async (id) => {
  try {
    const res = await deleteSalesman(id);
    if (res.success) {
      console.log("Salesman deleted successfully");
    } else {
      console.error("Failed to delete salesman:", res.message);
    }
    return res;
  } catch (error) {
    console.error("Delete salesman API error:", error);
    throw error;
  }
};
